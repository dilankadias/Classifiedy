<?php

$blockchain_root = "https://blockchain.info/";
$blockchain_receive_root = "https://api.blockchain.info/";
$mysite_root = "http://mysite.com/";
$secret = "CHANGE_TO_RANDOM_SECRET";
$my_xpub = "CHANGE_TO_XPUB_KEY";
$my_api_key = "CHANGE_TO_API_KEY";

//Database
$mysql_host = 'localhost';
$mysql_username = 'root';
$mysql_password = 'root';
$mysql_database = 'mysite';

?>
