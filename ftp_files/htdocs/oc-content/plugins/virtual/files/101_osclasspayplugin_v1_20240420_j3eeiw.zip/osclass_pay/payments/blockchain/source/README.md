# Instructions
    * Clone the git repository into the ROOT of your web server.
    * cd /www/receive_payment_php_demo
    * chmod 755 ./
    * Navigate to setup.php in your browser
    * http://localhost/receive_payment_php_demo/setup.php
    * Now the database is initialized open the demo
    * http://localhost/receive_payment_php_demo/index.php
